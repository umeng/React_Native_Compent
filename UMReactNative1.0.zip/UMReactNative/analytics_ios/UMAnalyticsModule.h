//
//  analytics.h
//  analytics
//
//
//  Copyright (c) 2016年 tendcloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
@interface UMAnalyticsModule : NSObject  <RCTBridgeModule>

@end
