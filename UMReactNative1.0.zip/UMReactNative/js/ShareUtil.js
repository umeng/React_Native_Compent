/**
 * Created by wangfei on 17/8/28.
 */
var { NativeModules } = require('react-native');
module.exports = NativeModules.UMShareModule;
