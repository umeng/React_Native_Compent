/**
 * Created by wangfei on 17/8/30.
 */
var { NativeModules } = require('react-native');
module.exports = NativeModules.UMAnalyticsModule;